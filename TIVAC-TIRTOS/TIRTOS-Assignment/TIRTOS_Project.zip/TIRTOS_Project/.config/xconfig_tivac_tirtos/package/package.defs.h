/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xconfig_tivac_tirtos__
#define xconfig_tivac_tirtos__



#endif /* xconfig_tivac_tirtos__ */ 
